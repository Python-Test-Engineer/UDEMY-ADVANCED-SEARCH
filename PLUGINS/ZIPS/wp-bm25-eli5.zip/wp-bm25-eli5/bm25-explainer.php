<?php
/**
 * Plugin Name: BM25 Ranking Explainer
 * Description: Simple yet detailed explanation of BM25 and ranking algorithms with interactive examples
 * Version: 1.0
 * Author: Your Name
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Add admin menu
add_action('admin_menu', 'bm25_explainer_menu');

function bm25_explainer_menu() {
    add_menu_page(
        'BM25 Ranking Guide',
        'BM25 Guide',
        'manage_options',
        'bm25-explainer',
        'bm25_explainer_page',
        'dashicons-chart-line',
        30
    );
}

// Main admin page
function bm25_explainer_page() {
    ?>
    <div class="wrap">
        <h1>🎯 Understanding BM25 and Ranking Algorithms</h1>
        <p style="font-size: 16px; max-width: 800px;">
            Ever wonder how search engines decide which results to show you first? Let's explore BM25, 
            one of the most important ranking algorithms used by search engines like Elasticsearch and many others!
        </p>

        <!-- Section 1: What is Ranking? -->
        <div class="bm25-section">
            <h2>📊 What is Ranking? (The Basics)</h2>
            <div class="bm25-card">
                <h3>Think of it like a library...</h3>
                <p>Imagine you walk into a library and ask: <strong>"I need books about cats"</strong></p>
                
                <p>The librarian could:</p>
                <ul>
                    <li>❌ Give you EVERY book that mentions "cats" (thousands of books!)</li>
                    <li>✅ Give you the MOST RELEVANT books about cats, sorted by importance</li>
                </ul>
                
                <p><strong>Ranking is how we decide which books are "most relevant"</strong></p>
                
                <div class="example-box">
                    <h4>🔍 Example: Searching for "chocolate cake recipe"</h4>
                    <table class="widefat">
                        <thead>
                            <tr>
                                <th>Document</th>
                                <th>Why It Ranks High/Low</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr style="background: #d4edda;">
                                <td><strong>Rank #1:</strong> "Ultimate Chocolate Cake Recipe"</td>
                                <td>✅ Has ALL your search words + they're in the title</td>
                            </tr>
                            <tr style="background: #fff3cd;">
                                <td><strong>Rank #2:</strong> "Best Chocolate Recipes: Cookies, Cakes, and More"</td>
                                <td>⚠️ Has your words but also talks about other things</td>
                            </tr>
                            <tr style="background: #f8d7da;">
                                <td><strong>Rank #10:</strong> "Vanilla Cake Recipe (mentions chocolate once)"</td>
                                <td>❌ Only mentions "chocolate" briefly, mostly about vanilla</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Section 2: Simple Ranking Methods -->
        <div class="bm25-section">
            <h2>🔢 Simple Ranking: Counting Words</h2>
            <div class="bm25-card">
                <h3>The Naive Approach: Just Count!</h3>
                <p>The simplest way to rank documents is to count how many times your search words appear.</p>
                
                <div class="example-box">
                    <h4>Search query: "pizza"</h4>
                    <table class="widefat">
                        <thead>
                            <tr>
                                <th>Document</th>
                                <th>Times "pizza" appears</th>
                                <th>Rank</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Doc A: "I love pizza! Pizza is great. Pizza for dinner!"</td>
                                <td>3</td>
                                <td>🥇 #1</td>
                            </tr>
                            <tr>
                                <td>Doc B: "Pizza recipe: make delicious pizza"</td>
                                <td>2</td>
                                <td>🥈 #2</td>
                            </tr>
                            <tr>
                                <td>Doc C: "My favorite food is pizza"</td>
                                <td>1</td>
                                <td>🥉 #3</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="warning-box">
                    <h4>⚠️ The Problem with Simple Counting</h4>
                    <p>What if someone writes "pizza pizza pizza pizza pizza" 100 times? They'd rank #1 even though it's spam!</p>
                    <p><strong>We need smarter ranking. Enter: BM25!</strong></p>
                </div>
            </div>
        </div>

        <!-- Section 3: What is BM25? -->
        <div class="bm25-section">
            <h2>🚀 What is BM25?</h2>
            <div class="bm25-card">
                <h3>BM25 = "Best Match 25"</h3>
                <p>BM25 is a smart ranking formula that considers THREE important things:</p>
                
                <ol style="font-size: 16px; line-height: 2;">
                    <li><strong>How often does the word appear?</strong> (Term Frequency)</li>
                    <li><strong>How rare is this word?</strong> (Inverse Document Frequency)</li>
                    <li><strong>How long is the document?</strong> (Document Length Normalization)</li>
                </ol>

                <div class="info-box">
                    <h4>🎓 Why "25"?</h4>
                    <p>It's the 25th variation of the "Best Match" formula family. Previous versions were BM1, BM11, BM15, etc. 
                    BM25 became the most popular because it works really well!</p>
                </div>
            </div>
        </div>

        <!-- Section 4: The Three Components -->
        <div class="bm25-section">
            <h2>🔍 The Three Magic Ingredients of BM25</h2>
            
            <!-- Component 1: Term Frequency -->
            <div class="bm25-card">
                <h3>1️⃣ Term Frequency (TF): How Often Does the Word Appear?</h3>
                <p><strong>The idea:</strong> If a document mentions your search word more times, it's probably more relevant.</p>
                
                <div class="example-box">
                    <h4>Example: Searching for "javascript"</h4>
                    <ul>
                        <li>Doc A mentions "javascript" 1 time → Less relevant</li>
                        <li>Doc B mentions "javascript" 5 times → More relevant</li>
                        <li>Doc C mentions "javascript" 50 times → Probably spam or overly repetitive</li>
                    </ul>
                </div>

                <p><strong>BM25's clever trick:</strong> It uses <em>saturation</em>. This means:</p>
                <ul>
                    <li>1 → 5 mentions = Big boost! 📈</li>
                    <li>5 → 10 mentions = Smaller boost 📊</li>
                    <li>10 → 50 mentions = Tiny boost (almost no difference) 📉</li>
                </ul>

                <p>This prevents spam documents from dominating just by repeating words endlessly!</p>
            </div>

            <!-- Component 2: IDF -->
            <div class="bm25-card">
                <h3>2️⃣ Inverse Document Frequency (IDF): How Rare Is the Word?</h3>
                <p><strong>The idea:</strong> Rare words are more important than common words.</p>
                
                <div class="example-box">
                    <h4>🤔 Think about it this way...</h4>
                    <p>You're searching for: <strong>"quantum physics"</strong></p>
                    <ul>
                        <li><strong>"quantum"</strong> → Appears in 100 documents → Rare! Very informative! 🌟</li>
                        <li><strong>"physics"</strong> → Appears in 10,000 documents → Common! Less informative! ⭐</li>
                    </ul>
                    
                    <p>Now compare to: <strong>"the physics"</strong></p>
                    <ul>
                        <li><strong>"the"</strong> → Appears in almost EVERY document → Nearly useless! 💤</li>
                        <li><strong>"physics"</strong> → Still appears in 10,000 documents → Somewhat useful ⭐</li>
                    </ul>
                </div>

                <div class="info-box">
                    <h4>📐 The Math (Simplified)</h4>
                    <p>IDF = log(Total Documents / Documents containing word)</p>
                    <ul>
                        <li>If EVERYONE uses the word → IDF is LOW (close to 0)</li>
                        <li>If NOBODY uses the word → IDF is HIGH (big number)</li>
                    </ul>
                    <p><strong>Translation:</strong> Rare words get bonus points! 🎁</p>
                </div>
            </div>

            <!-- Component 3: Document Length -->
            <div class="bm25-card">
                <h3>3️⃣ Document Length Normalization: Size Matters!</h3>
                <p><strong>The problem:</strong> Long documents naturally mention words more times.</p>
                
                <div class="example-box">
                    <h4>Example: Searching for "machine learning"</h4>
                    <p><strong>Document A:</strong> Short blog post (200 words)</p>
                    <ul><li>Mentions "machine learning" 3 times</li></ul>
                    
                    <p><strong>Document B:</strong> Entire textbook (50,000 words)</p>
                    <ul><li>Mentions "machine learning" 50 times</li></ul>
                    
                    <p><strong>Question:</strong> Is Document B really 16x more relevant? Or is it just 250x longer?</p>
                </div>

                <p><strong>BM25's solution:</strong> It adjusts scores based on document length.</p>
                <ul>
                    <li>Short document with many mentions → Gets a boost! 🚀</li>
                    <li>Long document with many mentions → Gets penalized slightly 📉</li>
                </ul>

                <div class="info-box">
                    <h4>🎯 Real-world Impact</h4>
                    <p>This prevents giant documents (like legal terms or Wikipedia articles) from always ranking #1 
                    just because they're long and mention everything!</p>
                </div>
            </div>
        </div>

        <!-- Section 5: BM25 Formula -->
        <div class="bm25-section">
            <h2>🧮 The BM25 Formula (Don't Panic!)</h2>
            <div class="bm25-card">
                <div class="formula-box">
                    <h3>The Official Formula:</h3>
                    <pre style="background: #f5f5f5; padding: 20px; overflow-x: auto; border-left: 4px solid #2271b1;">
Score(D,Q) = Σ IDF(qi) × (f(qi,D) × (k1 + 1)) / (f(qi,D) + k1 × (1 - b + b × |D| / avgdl))
                    </pre>
                </div>

                <h3>😰 Looks scary? Let's translate it!</h3>
                
                <div class="translation-box">
                    <h4>What each symbol means:</h4>
                    <table class="widefat">
                        <tr>
                            <td><strong>D</strong></td>
                            <td>The Document we're scoring</td>
                        </tr>
                        <tr>
                            <td><strong>Q</strong></td>
                            <td>The Query (search terms)</td>
                        </tr>
                        <tr>
                            <td><strong>Σ</strong></td>
                            <td>"Sum up" - do this for each word in the query</td>
                        </tr>
                        <tr>
                            <td><strong>IDF(qi)</strong></td>
                            <td>How rare is this query word?</td>
                        </tr>
                        <tr>
                            <td><strong>f(qi,D)</strong></td>
                            <td>How many times does the word appear in this document?</td>
                        </tr>
                        <tr>
                            <td><strong>|D|</strong></td>
                            <td>Length of this document</td>
                        </tr>
                        <tr>
                            <td><strong>avgdl</strong></td>
                            <td>Average document length across all documents</td>
                        </tr>
                        <tr>
                            <td><strong>k1</strong></td>
                            <td>Controls term frequency saturation (usually 1.2-2.0)</td>
                        </tr>
                        <tr>
                            <td><strong>b</strong></td>
                            <td>Controls length normalization (usually 0.75)</td>
                        </tr>
                    </table>
                </div>

                <h3>In Plain English:</h3>
                <div class="plain-english-box">
                    <p style="font-size: 16px; line-height: 1.8;">
                        "For each word in the search query, calculate how important it is (IDF) and multiply that by 
                        how often it appears in the document (TF). Then adjust this score based on how long the document is. 
                        Add up all these scores for each search word, and you get the final ranking score!"
                    </p>
                </div>
            </div>
        </div>

        <!-- Section 6: Step-by-Step Example -->
        <div class="bm25-section">
            <h2>👣 Complete Step-by-Step Example</h2>
            <div class="bm25-card">
                <h3>Let's Calculate BM25 Score Together!</h3>
                
                <div class="scenario-box">
                    <h4>📚 The Scenario</h4>
                    <p><strong>Search Query:</strong> "chocolate cake"</p>
                    <p><strong>Our Collection:</strong></p>
                    <ul>
                        <li>100 total documents</li>
                        <li>Average document length: 50 words</li>
                    </ul>
                    
                    <p><strong>Document to Score:</strong> "This chocolate cake recipe is amazing. The chocolate frosting makes the cake perfect!"</p>
                    <ul>
                        <li>Length: 14 words</li>
                        <li>"chocolate" appears: 2 times</li>
                        <li>"cake" appears: 2 times</li>
                    </ul>

                    <p><strong>Word Statistics:</strong></p>
                    <ul>
                        <li>"chocolate" appears in 30 out of 100 documents</li>
                        <li>"cake" appears in 40 out of 100 documents</li>
                    </ul>
                </div>

                <h3>Step 1: Calculate IDF for each word</h3>
                <div class="calculation-box">
                    <p><strong>For "chocolate":</strong></p>
                    <pre>IDF = log(100 / 30) = log(3.33) = 1.20</pre>
                    <p>Interpretation: "chocolate" is somewhat selective</p>

                    <p><strong>For "cake":</strong></p>
                    <pre>IDF = log(100 / 40) = log(2.5) = 0.92</pre>
                    <p>Interpretation: "cake" is less selective (more common)</p>
                </div>

                <h3>Step 2: Calculate Term Frequency component</h3>
                <div class="calculation-box">
                    <p>Using k1 = 1.5 (standard value)</p>
                    
                    <p><strong>For "chocolate" (appears 2 times):</strong></p>
                    <pre>TF component = (2 × 2.5) / (2 + 1.5 × ...) 
                 = 5 / (2 + length adjustment)
                 ≈ 1.56  (after length adjustment)</pre>

                    <p><strong>For "cake" (appears 2 times):</strong></p>
                    <pre>TF component ≈ 1.56  (same frequency, same adjustment)</pre>
                </div>

                <h3>Step 3: Apply Length Normalization</h3>
                <div class="calculation-box">
                    <p>Using b = 0.75 (standard value)</p>
                    <p>Document is 14 words, average is 50 words</p>
                    
                    <pre>Length ratio = 14 / 50 = 0.28
Normalization = 1 - 0.75 + 0.75 × 0.28 = 0.46</pre>
                    
                    <p>This document is SHORTER than average, so it gets a slight boost! 🚀</p>
                </div>

                <h3>Step 4: Combine Everything</h3>
                <div class="calculation-box">
                    <p><strong>Score for "chocolate":</strong></p>
                    <pre>1.20 (IDF) × 1.56 (TF adjusted) = 1.87</pre>

                    <p><strong>Score for "cake":</strong></p>
                    <pre>0.92 (IDF) × 1.56 (TF adjusted) = 1.44</pre>

                    <p><strong>FINAL BM25 SCORE:</strong></p>
                    <pre style="font-size: 18px; font-weight: bold;">1.87 + 1.44 = 3.31 🎯</pre>
                </div>

                <div class="info-box">
                    <h4>📊 What does this score mean?</h4>
                    <ul>
                        <li>This score is compared against ALL other documents</li>
                        <li>Higher score = Better match = Higher ranking</li>
                        <li>If another document scored 5.2, it would rank higher</li>
                        <li>If another document scored 2.1, this one would rank higher</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Section 7: Tuning Parameters -->
        <div class="bm25-section">
            <h2>🎛️ Tuning BM25: The k1 and b Parameters</h2>
            
            <div class="bm25-card">
                <h3>Parameter k1: Term Frequency Saturation</h3>
                <p><strong>What it controls:</strong> How quickly repeated words stop mattering</p>
                
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>k1 Value</th>
                            <th>Effect</th>
                            <th>Use Case</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>0</td>
                            <td>Term frequency doesn't matter at all (just presence/absence)</td>
                            <td>When you want binary matching</td>
                        </tr>
                        <tr>
                            <td>1.2</td>
                            <td>Quick saturation - word counts matter less after a few mentions</td>
                            <td>🌟 Most common default - good for general search</td>
                        </tr>
                        <tr>
                            <td>2.0</td>
                            <td>Slower saturation - word counts keep mattering longer</td>
                            <td>When you want repeated mentions to count more</td>
                        </tr>
                        <tr>
                            <td>∞</td>
                            <td>No saturation - linear relationship with word count</td>
                            <td>Usually not recommended (vulnerable to spam)</td>
                        </tr>
                    </tbody>
                </table>

                <div class="example-box">
                    <h4>Visual Comparison:</h4>
                    <p>Document mentions "python" this many times:</p>
                    <ul>
                        <li>k1=1.2: 1 mention→1.0x, 5 mentions→1.8x, 10 mentions→2.0x, 20 mentions→2.1x</li>
                        <li>k1=2.0: 1 mention→1.0x, 5 mentions→2.1x, 10 mentions→2.5x, 20 mentions→2.8x</li>
                    </ul>
                    <p>Notice how k1=1.2 "levels off" faster! 📉</p>
                </div>
            </div>

            <div class="bm25-card">
                <h3>Parameter b: Document Length Normalization</h3>
                <p><strong>What it controls:</strong> How much document length affects the score</p>
                
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>b Value</th>
                            <th>Effect</th>
                            <th>Use Case</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>0</td>
                            <td>Length doesn't matter at all</td>
                            <td>When all documents are similar length</td>
                        </tr>
                        <tr>
                            <td>0.75</td>
                            <td>Balanced length consideration</td>
                            <td>🌟 Most common default - works well for varied content</td>
                        </tr>
                        <tr>
                            <td>1.0</td>
                            <td>Full length normalization</td>
                            <td>When document lengths vary widely</td>
                        </tr>
                    </tbody>
                </table>

                <div class="example-box">
                    <h4>Impact Example:</h4>
                    <p>Two documents, both mention "database" 5 times:</p>
                    <ul>
                        <li><strong>Doc A:</strong> 100 words (short)</li>
                        <li><strong>Doc B:</strong> 1,000 words (long)</li>
                    </ul>
                    
                    <p><strong>With b=0 (no normalization):</strong> Both score the same</p>
                    <p><strong>With b=0.75:</strong> Doc A scores higher (more focused!)</p>
                    <p><strong>With b=1.0:</strong> Doc A scores even higher</p>
                </div>
            </div>
        </div>

        <!-- Section 8: Practical Applications -->
        <div class="bm25-section">
            <h2>🌍 Where is BM25 Used?</h2>
            <div class="bm25-card">
                <h3>Real-World Systems Using BM25:</h3>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
                    <div class="app-box">
                        <h4>🔍 Elasticsearch</h4>
                        <p>The most popular search engine for websites and apps. BM25 is the default scoring algorithm!</p>
                    </div>
                    
                    <div class="app-box">
                        <h4>🌐 Apache Lucene/Solr</h4>
                        <p>Powers search for major websites including GitHub, Netflix catalog search, and more.</p>
                    </div>
                    
                    <div class="app-box">
                        <h4>🤖 Retrieval Systems</h4>
                        <p>Used in RAG (Retrieval Augmented Generation) to find relevant documents for AI chatbots.</p>
                    </div>
                    
                    <div class="app-box">
                        <h4>📚 Digital Libraries</h4>
                        <p>Academic search engines, digital libraries, and document management systems.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 9: BM25 vs Other Methods -->
        <div class="bm25-section">
            <h2>⚖️ BM25 vs Other Ranking Methods</h2>
            <div class="bm25-card">
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>Method</th>
                            <th>Pros</th>
                            <th>Cons</th>
                            <th>Best For</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Simple TF (Term Frequency)</strong></td>
                            <td>Very fast, easy to understand</td>
                            <td>Easily gamed, no nuance, favors long docs</td>
                            <td>Quick prototypes only</td>
                        </tr>
                        <tr>
                            <td><strong>TF-IDF</strong></td>
                            <td>Fast, considers word rarity</td>
                            <td>No saturation, linear scaling issues</td>
                            <td>Basic search, document classification</td>
                        </tr>
                        <tr style="background: #d4edda;">
                            <td><strong>BM25</strong></td>
                            <td>Balanced, handles length well, battle-tested, fast</td>
                            <td>Doesn't understand synonyms or meaning</td>
                            <td>🌟 Most text search applications</td>
                        </tr>
                        <tr>
                            <td><strong>Neural/Semantic Search</strong></td>
                            <td>Understands meaning, handles synonyms</td>
                            <td>Slower, needs more resources, harder to explain</td>
                            <td>When you need semantic understanding</td>
                        </tr>
                    </tbody>
                </table>

                <div class="info-box">
                    <h4>💡 Pro Tip: Hybrid Approach</h4>
                    <p>Many modern systems use BOTH BM25 and neural search:</p>
                    <ul>
                        <li>BM25 for fast, keyword-based retrieval</li>
                        <li>Neural models for re-ranking top results with semantic understanding</li>
                    </ul>
                    <p>This gives you the best of both worlds! 🎯</p>
                </div>
            </div>
        </div>

        <!-- Section 10: Common Pitfalls -->
        <div class="bm25-section">
            <h2>⚠️ Common Mistakes and How to Avoid Them</h2>
            
            <div class="bm25-card">
                <h3>Mistake #1: Not Handling Stop Words</h3>
                <div class="mistake-box">
                    <p><strong>Problem:</strong> Words like "the", "is", "at" appear everywhere and add noise.</p>
                    <p><strong>Solution:</strong> Remove stop words BEFORE indexing, or they'll affect IDF calculations.</p>
                    <p><strong>Example:</strong> "the best pizza" → "best pizza" (remove "the")</p>
                </div>
            </div>

            <div class="bm25-card">
                <h3>Mistake #2: Not Stemming/Lemmatizing</h3>
                <div class="mistake-box">
                    <p><strong>Problem:</strong> "running", "runs", "ran" are treated as completely different words!</p>
                    <p><strong>Solution:</strong> Use stemming to reduce words to their root form.</p>
                    <p><strong>Example:</strong> "running" → "run", "better" → "good"</p>
                </div>
            </div>

            <div class="bm25-card">
                <h3>Mistake #3: Wrong Parameter Values</h3>
                <div class="mistake-box">
                    <p><strong>Problem:</strong> Using default k1 and b for all use cases.</p>
                    <p><strong>Solution:</strong> Tune parameters based on your content:</p>
                    <ul>
                        <li>Short documents (tweets)? → Lower b (maybe 0.5)</li>
                        <li>Technical docs where terms repeat? → Higher k1 (maybe 1.8)</li>
                    </ul>
                </div>
            </div>

            <div class="bm25-card">
                <h3>Mistake #4: Not Considering Field Weighting</h3>
                <div class="mistake-box">
                    <p><strong>Problem:</strong> Title matches should count more than body matches!</p>
                    <p><strong>Solution:</strong> Apply BM25 separately to different fields and weight them:</p>
                    <ul>
                        <li>Title match: 3.0× weight</li>
                        <li>Body match: 1.0× weight</li>
                        <li>Comments: 0.5× weight</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Section 11: Quick Reference -->
        <div class="bm25-section">
            <h2>📋 Quick Reference Guide</h2>
            <div class="bm25-card">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                    <div class="reference-box">
                        <h4>🎯 Best Practices</h4>
                        <ul>
                            <li>✅ Start with k1=1.2, b=0.75</li>
                            <li>✅ Remove stop words</li>
                            <li>✅ Apply stemming</li>
                            <li>✅ Weight title fields higher</li>
                        </ul>
                    </div>
                    
                    <div class="reference-box">
                        <h4>📊 When to Use BM25</h4>
                        <ul>
                            <li>✅ Keyword-based search</li>
                            <li>✅ Documents vary in length</li>
                            <li>✅ Need fast responses</li>
                            <li>✅ Exact term matching important</li>
                        </ul>
                    </div>
                    
                    <div class="reference-box">
                        <h4>🚫 When NOT to Use BM25</h4>
                        <ul>
                            <li>❌ Need semantic understanding</li>
                            <li>❌ Synonym matching crucial</li>
                            <li>❌ Multi-language search</li>
                            <li>❌ Question answering</li>
                        </ul>
                    </div>
                    
                    <div class="reference-box">
                        <h4>🔧 Default Parameters</h4>
                        <ul>
                            <li><strong>k1:</strong> 1.2 to 2.0</li>
                            <li><strong>b:</strong> 0.75</li>
                            <li><strong>δ:</strong> 0.5 (BM25+)</li>
                            <li>Tune based on your data!</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 12: Try It Yourself -->
        <div class="bm25-section">
            <h2>🧪 Mental Exercise: Calculate BM25 Yourself!</h2>
            <div class="bm25-card">
                <div class="exercise-box">
                    <h3>Practice Problem</h3>
                    <p><strong>Given:</strong></p>
                    <ul>
                        <li>Total documents: 200</li>
                        <li>Average document length: 40 words</li>
                        <li>Query: "machine learning"</li>
                        <li>k1 = 1.5, b = 0.75</li>
                    </ul>
                    
                    <p><strong>Document:</strong> "Machine learning algorithms require machine learning experts"</p>
                    <ul>
                        <li>Length: 8 words</li>
                        <li>"machine" appears: 2 times</li>
                        <li>"learning" appears: 2 times</li>
                    </ul>
                    
                    <p><strong>Word Statistics:</strong></p>
                    <ul>
                        <li>"machine" in 50/200 documents</li>
                        <li>"learning" in 60/200 documents</li>
                    </ul>
                    
                    <p><strong>Your Task:</strong> Calculate the approximate BM25 score!</p>
                    
                    <details style="margin-top: 20px; padding: 15px; background: #f0f0f0;">
                        <summary style="cursor: pointer; font-weight: bold;">📖 Show Answer & Walkthrough</summary>
                        <div style="margin-top: 15px;">
                            <h4>Step 1: Calculate IDF</h4>
                            <p>IDF("machine") = log(200/50) = log(4) ≈ 1.39</p>
                            <p>IDF("learning") = log(200/60) = log(3.33) ≈ 1.20</p>
                            
                            <h4>Step 2: Length Normalization</h4>
                            <p>Length factor = 1 - 0.75 + 0.75 × (8/40) = 1 - 0.75 + 0.15 = 0.40</p>
                            
                            <h4>Step 3: TF Component (simplified)</h4>
                            <p>For each word appearing 2 times with this short document, TF ≈ 1.7</p>
                            
                            <h4>Step 4: Final Score</h4>
                            <p>Score ≈ (1.39 × 1.7) + (1.20 × 1.7) ≈ 2.36 + 2.04 = <strong>4.40</strong></p>
                        </div>
                    </details>
                </div>
            </div>
        </div>

        <!-- CSS Styles -->
        <style>
            .bm25-section {
                margin: 30px 0;
                padding: 20px;
                background: white;
                border-left: 4px solid #2271b1;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            }
            
            .bm25-card {
                margin: 20px 0;
                padding: 20px;
                background: #f9f9f9;
                border-radius: 5px;
            }
            
            .example-box, .info-box, .warning-box, .calculation-box, 
            .scenario-box, .translation-box, .plain-english-box, .mistake-box,
            .app-box, .reference-box, .exercise-box {
                margin: 15px 0;
                padding: 15px;
                border-radius: 5px;
            }
            
            .example-box {
                background: #e7f3ff;
                border-left: 4px solid #2196F3;
            }
            
            .info-box {
                background: #e8f5e9;
                border-left: 4px solid #4CAF50;
            }
            
            .warning-box {
                background: #fff3e0;
                border-left: 4px solid #FF9800;
            }
            
            .calculation-box {
                background: #f3e5f5;
                border-left: 4px solid #9C27B0;
                font-family: monospace;
            }
            
            .scenario-box {
                background: #e0f7fa;
                border-left: 4px solid #00BCD4;
            }
            
            .formula-box {
                background: #fff;
                padding: 20px;
                border: 2px solid #2271b1;
                border-radius: 5px;
                margin: 15px 0;
            }
            
            .translation-box {
                background: #fce4ec;
                border-left: 4px solid #E91E63;
            }
            
            .plain-english-box {
                background: #fff9c4;
                border-left: 4px solid #FFC107;
                padding: 20px;
                font-style: italic;
            }
            
            .mistake-box {
                background: #ffebee;
                border-left: 4px solid #f44336;
            }
            
            .app-box, .reference-box {
                background: white;
                border: 2px solid #e0e0e0;
                padding: 15px;
            }
            
            .exercise-box {
                background: #e1f5fe;
                border: 2px solid #03A9F4;
                padding: 20px;
            }
            
            h2 {
                color: #2271b1;
                border-bottom: 2px solid #2271b1;
                padding-bottom: 10px;
            }
            
            h3 {
                color: #135e96;
                margin-top: 20px;
            }
            
            h4 {
                color: #0a3f5e;
            }
            
            .widefat {
                margin: 15px 0;
            }
            
            .widefat th {
                background: #2271b1;
                color: white;
            }
            
            pre {
                background: #f5f5f5;
                padding: 10px;
                border-radius: 3px;
                overflow-x: auto;
            }
            
            ul, ol {
                line-height: 1.8;
            }
            
            strong {
                color: #2271b1;
            }
        </style>
    </div>
    <?php
}
